
export const domain ='https://localhost:44302/api/';
export const accessToken = 'accessToken';

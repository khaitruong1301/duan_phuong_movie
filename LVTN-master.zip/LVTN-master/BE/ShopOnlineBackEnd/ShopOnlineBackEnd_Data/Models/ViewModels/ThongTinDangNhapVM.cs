﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopOnlineBackEnd_Data.Models.ViewModels
{
    public class ThongTinDangNhap
    {
        public string TaiKhoan { get; set; }
        public string MatKhau { get; set; }
    }
}

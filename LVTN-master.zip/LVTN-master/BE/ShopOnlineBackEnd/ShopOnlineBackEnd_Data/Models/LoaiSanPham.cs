﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopOnlineBackEnd_Data.Models
{
   public class LoaiSanPham
    {
        public string MaLoaiSP { get; set; }
        public string TenLoai { get; set; }
        public string Icon { get; set; }
    }
}
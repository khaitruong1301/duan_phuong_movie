﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopOnlineBackEnd_Data.Models
{
    public class LoaiNguoiDung
    {
        public string MaLoai { get; set; }
        public string TenLoai { get; set; }
    }
}

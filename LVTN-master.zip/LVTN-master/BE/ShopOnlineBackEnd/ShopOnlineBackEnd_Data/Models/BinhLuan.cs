﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopOnlineBackEnd_Data.Models
{
    public class BinhLuan
    {
        public int MaBL { get; set; }
        public int DanhGia { get; set; }
        public string NoiDung { get; set; }
        public string MaSP { get; set; }
        public int MaKH { get; set; }
        public string NgayTao { get; set; }
    }
   
    
}